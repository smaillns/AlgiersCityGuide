package com.example.smail.algiers_city_guide.entity

class Spot(var id:Int, var name:String, var image:Int,
           var lat:Long, var long:Long, var description: String,
           var phone:String?, var link:String) {
}