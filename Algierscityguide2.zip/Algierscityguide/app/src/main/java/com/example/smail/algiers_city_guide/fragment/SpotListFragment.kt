package com.example.smail.algiers_city_guide.fragment


import android.app.Activity
import android.location.Location
import android.os.Bundle
import android.os.Handler
import android.support.v4.app.Fragment
import android.support.v7.view.ActionMode
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout

import com.example.smail.algiers_city_guide.R
import com.example.smail.algiers_city_guide.adapter.SpotListAdapter
import com.example.smail.algiers_city_guide.entity.Spot
import com.example.smail.algiers_city_guide.gelocation.Geolocation
import com.example.smail.algiers_city_guide.listener.OnSearchListener
import com.example.smail.algiers_city_guide.view.ViewState

class SpotListFragment : Fragment() {

    val CATEGORY_ID_ALL = -1L
    val CATEGORY_ID_FAVORITES = -2L
    val CATEGORY_ID_SEARCH = -3L

    private val ARGUMENT_CATEGORY_ID = "category_id"
    private val ARGUMENT_SEARCH_QUERY = "search_query"
    private val DIALOG_ABOUT = "about"
    private val TIMER_DELAY = 60000L // in milliseconds
    private val LAZY_LOADING_TAKE = 128
    private val LAZY_LOADING_OFFSET = 4


    private var mLazyLoading = false
    private var mViewState: ViewState? = null
    private var mRootView: View? = null
    private var mAdapter: SpotListAdapter? = null
    private var mSearchListener: OnSearchListener? = null
    private var mActionMode: ActionMode? = null
//    private val mDatabaseCallManager = DatabaseCallManager()
    private var mGeolocation: Geolocation? = null
    private var mLocation: Location? = null
    private var mTimerHandler: Handler? = null
    private var mTimerRunnable: Runnable? = null


    private var mCategoryId: Long = 0
    private var mSearchQuery: String? = null

    private val mFooterList = java.util.ArrayList<Any>()


    private lateinit var recyclerView: RecyclerView
    private lateinit var viewAdapter: RecyclerView.Adapter<*>
    private lateinit var viewManager: RecyclerView.LayoutManager

    val mDataset = ArrayList<Spot>()


    fun newInstance(categoryId: Long): SpotListFragment {
        val fragment = SpotListFragment()

        // arguments
        val arguments = Bundle()
        arguments.putLong(ARGUMENT_CATEGORY_ID, categoryId)
        fragment.setArguments(arguments)

        return fragment
    }

    fun newInstance(searchQuery: String): SpotListFragment {
        val fragment = SpotListFragment()

        // arguments
        val arguments = Bundle()
        arguments.putLong(ARGUMENT_CATEGORY_ID, CATEGORY_ID_SEARCH)
        arguments.putString(ARGUMENT_SEARCH_QUERY, searchQuery)
        fragment.setArguments(arguments)

        return fragment
    }

    override fun onAttach(activity: Activity) {
        super.onAttach(activity)

        // set search listener
 /*       try {
           mSearchListener = activity as OnSearchListener
        } catch (e: ClassCastException) {
            throw ClassCastException(activity.javaClass.name + " must implement " + OnSearchListener::class.java.name)
        }*/

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setHasOptionsMenu(true)
        retainInstance = true

        // handle fragment arguments
        val arguments = arguments
        if (arguments != null) {
            handleArguments(arguments)
        }
    }

    private fun handleArguments(arguments: Bundle) {
        mCategoryId = arguments.getLong(ARGUMENT_CATEGORY_ID, CATEGORY_ID_ALL)
        mSearchQuery = arguments.getString(ARGUMENT_SEARCH_QUERY, "")
    }



    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_spot_list, container, false)
    }



    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initData()

        viewAdapter = SpotListAdapter(mDataset, getActivity()!!)
        viewManager = LinearLayoutManager(getActivity(), LinearLayout.VERTICAL, false)


        recyclerView = getActivity()!!.findViewById<RecyclerView>(R.id.list_spot_recycler_view).apply {
            setHasFixedSize(true)
            layoutManager = viewManager
            adapter = viewAdapter

        }
    }



    private fun setupRecyclerView() {
        val gridLayoutManager = GridLayoutManager(activity, getGridSpanCount())
        gridLayoutManager.orientation = GridLayoutManager.VERTICAL
        val recyclerView = getRecyclerView()
        recyclerView!!.setLayoutManager(gridLayoutManager)
    }


    private fun getGridSpanCount(): Int {
        val display = activity!!.getWindowManager().defaultDisplay
        val displayMetrics = DisplayMetrics()
        display.getMetrics(displayMetrics)
        val screenWidth = displayMetrics.widthPixels.toFloat()
        val cellWidth = resources.getDimension(R.dimen.fragment_spot_list_recycler_item_size)
        return Math.round(screenWidth / cellWidth)
    }

    private fun getRecyclerView(): RecyclerView? {
        return if (mRootView != null) mRootView!!.findViewById<View>(R.id.list_spot_recycler_view) as RecyclerView else null
    }





    private fun loadData() {
//        if (!mDatabaseCallManager.hasRunningTask(PoiReadAllQuery::class.java) &&
//                !mDatabaseCallManager.hasRunningTask(PoiReadFavoritesQuery::class.java) &&
//                !mDatabaseCallManager.hasRunningTask(PoiSearchQuery::class.java) &&
//                !mDatabaseCallManager.hasRunningTask(PoiReadByCategoryQuery::class.java)) {
//            // show progress
//            showProgress()
//
//            // run async task
//            val query: Query
//            if (mCategoryId == CATEGORY_ID_ALL) {
//                query = PoiReadAllQuery(0, LAZY_LOADING_TAKE)
//            } else if (mCategoryId == CATEGORY_ID_FAVORITES) {
//                query = PoiReadFavoritesQuery(0, LAZY_LOADING_TAKE)
//            } else if (mCategoryId == CATEGORY_ID_SEARCH) {
//                query = PoiSearchQuery(mSearchQuery, 0, LAZY_LOADING_TAKE)
//            } else {
//                query = PoiReadByCategoryQuery(mCategoryId, 0, LAZY_LOADING_TAKE)
//            }
//            mDatabaseCallManager.executeTask(query, this)
//        }
        initData()
    }



    fun initData() {
        mDataset.add(Spot(1,"nom1",1,3,3,"Description","0552349395",""))
        mDataset.add(Spot(1,"nom2",1,3,3,"Description","0552349395",""))
        mDataset.add(Spot(1,"nom3",1,3,3,"Description","0552349395",""))
        mDataset.add(Spot(1,"nom4",1,3,3,"Description","0552349395",""))

    }


}
