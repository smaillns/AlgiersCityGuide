package com.example.smail.algiers_city_guide.entity

class Category(var id:Int, var name:String){

}