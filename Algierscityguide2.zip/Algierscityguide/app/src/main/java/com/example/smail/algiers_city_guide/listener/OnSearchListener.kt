package com.example.smail.algiers_city_guide.listener

interface OnSearchListener {

    abstract fun onSearch(query:String)

}