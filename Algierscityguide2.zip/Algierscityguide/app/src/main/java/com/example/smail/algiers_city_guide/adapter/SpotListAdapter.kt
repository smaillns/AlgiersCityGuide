package com.example.smail.algiers_city_guide.adapter

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.smail.algiers_city_guide.R
import com.example.smail.algiers_city_guide.entity.Spot

class SpotListAdapter(private var myDataset: ArrayList<Spot>, var mCtx: Context): RecyclerView.Adapter<SpotListAdapter.ViewHolder>() {

    class ViewHolder(holder : View) : RecyclerView.ViewHolder(holder){
        val nom = holder.findViewById<TextView>(R.id.textView)
    }



    override fun onCreateViewHolder(parent: ViewGroup,
                                    viewType: Int): ViewHolder {
        // create a new view
        val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.spot_item, parent, false)
        // set the view's size, margins, paddings and layout parameters

        return ViewHolder(v)
    }




    // Replace the contents of a view (invoked by the layout manager)
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element


        holder.nom.setText(myDataset[position].name)

    }

    // Return the size of your dataset (invoked by the layout manager)
    override fun getItemCount() = myDataset.size


}