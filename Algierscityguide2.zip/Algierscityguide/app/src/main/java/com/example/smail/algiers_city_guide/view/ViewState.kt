package com.example.smail.algiers_city_guide.view

enum class ViewState {
    CONTENT, PROGRESS, EMPTY, OFFLINE
}
