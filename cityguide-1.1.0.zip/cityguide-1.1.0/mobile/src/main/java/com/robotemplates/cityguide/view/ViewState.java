package com.robotemplates.cityguide.view;


public enum ViewState
{
	CONTENT, PROGRESS, OFFLINE, EMPTY
}
