package com.robotemplates.cityguide.listener;


public interface OnSearchListener
{
	public void onSearch(String query);
}
